#!/bin/bash

echo START lhci
rm -rf ./crawl4ai_url/user-data
rm -rf ./lighthouse-results
rm -rf ./sms_code_b.txt

sleep 2
python ./crawl4ai_url/crawl4aiGetUrl.py &
CRAWL_PID_B=$!
sleep 20
echo "Private Url_B 크롤링에 필요한 SMS 인증번호를 입력하세요:"
winpty bash -c 'read -r input; echo "$input" > sms_code_b.txt'
sleep 1

if [ -f "sms_code_b.txt" ]; then
    sms_code_b=$(cat sms_code_b.txt)
    echo "SMS_CODE_B 저장: $sms_code_b"
else
    echo "오류: SMS 인증번호 없음"
    exit 1 
fi

while ps -p $CRAWL_PID_B > /dev/null; do
    sleep 20
done

sleep 2
node autoLogin.js

sleep 2
echo new commit $(date) >> log.txt
git add log.txt
git commit -m "new commit"
git push origin master --force

sleep 2
lhci autorun

sleep 2
lhci upload --target=lhci --serverBaseUrl="http://localhost:19003/" --token="bd91db16-d204-440d-8eff-3803f1f1c5a2"

sleep 2
echo END lhci

node sep_score.js

sleep 2
# lhci 결과 압축
ZIP_FILE_PATH="./lighthouse-reports.zip"
RESULTS_DIR="./lighthouse-results"

chmod -R 777 "$RESULTS_DIR"
zip -r "$ZIP_FILE_PATH" "$RESULTS_DIR" > /dev/null
echo "ZIP lighthouse-report success"

sleep 2
python redmine_upload.py
