const fs = require('fs');
const path = require('path');
const puppeteer = require('puppeteer');

function getDomainName(url) {
  const hostname = new URL(url).hostname;
  const parts = hostname.split('.');

  // www로 시작하는 경우 제거
  //if (parts[0] === "www") {
  //  return parts.slice(1).join('_');
  //}

  return hostname.replace(/\./g, '_'); // .을 _로 변경
}

module.exports = async (browser, context) => {
    // lhci 분석 URL 가져오기
    const currentUrl = context.url;

    if (!currentUrl) {
      console.error('Error: No current URL provided by Lighthouse CI.');
      return;
    }
    console.log(`Analyzing URL: ${currentUrl}`);

    try {
      const page = await browser.newPage();
      const domainName =getDomainName(currentUrl)
      const cookiesPath = `./crawl4ai_url/user-data/cookies_${domainName}.json`;

      // 쿠키 복원
      if (fs.existsSync(cookiesPath)) {
        const cookies = JSON.parse(fs.readFileSync(cookiesPath, 'utf-8'));
        await page.setCookie(...cookies);
        console.log('Cookies restored successfully.');
      } else {
        console.error('Error: Cookies file not found.');
        return;
      }

      // 분석 대상 URL로 이동
      await page.goto(currentUrl, {
        waitUntil: 'load',
      });
      console.log(`Session established and page loaded for: ${currentUrl}`);
    } catch (error) {
      console.error('Error in reload_chrome.mjs:', error);
    }
};