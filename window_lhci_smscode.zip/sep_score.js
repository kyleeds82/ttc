const fs = require('fs');
const path = require('path');

// 파일 경로 설정
const manifestFilePath = path.join(__dirname, 'lighthouse-results', 'manifest.json');
const underScoreFilePath = path.join(__dirname, 'underScore.txt');
const upperScoreFilePath = path.join(__dirname, 'upperScore.txt');
const totalFilePath = path.join(__dirname, 'total_value.txt');

// JSON 파일 읽기
if (!fs.existsSync(manifestFilePath)) {
  console.error('manifest.json 파일을 찾을 수 없습니다.');
  process.exit(1);
}

const manifestData = JSON.parse(fs.readFileSync(manifestFilePath, 'utf-8'));

// 결과 저장용 배열
const underScoreResults = [];
const upperScoreResults = [];

// JSON 데이터 처리
manifestData.forEach((entry) => {
  const { url, summary } = entry;

  // 점수 값을 비교
  const performanceValue = summary.performance !== null ? Math.round(summary.performance * 100) : null;
  const accessibility = summary.accessibility !== null ? `${Math.round(summary.accessibility * 100)}%` : 'null';
  const bestPractices = summary['best-practices'] !== null ? `${Math.round(summary['best-practices'] * 100)}%` : 'null';
  const seo = summary.seo !== null ? `${Math.round(summary.seo * 100)}%` : 'null';

  const performance = performanceValue !== null ? `${performanceValue}%` : 'null';
  const result = `분석 결과 (${url}):
        - Performance: ${performance}
        - Accessibility: ${accessibility}
        - Best Practices: ${bestPractices}
        - SEO: ${seo}
`;

  // 퍼포먼스 값 기준으로 under, upper 설정정
  if (performanceValue !== null && performanceValue < 59) {
    underScoreResults.push(result);
  } else {
    upperScoreResults.push(result);
  }
});


// 결과 파일 저장
fs.writeFileSync(underScoreFilePath, underScoreResults.join('\n'), 'utf-8');
fs.writeFileSync(upperScoreFilePath, upperScoreResults.join('\n'), 'utf-8');


const totalContent = `-------- Under 58 ---\n\n${underScoreResults.join('\n')}\n\n\n-------- Upper 58 ---\n\n${upperScoreResults.join('\n')}`;

// 파일 쓰기
fs.writeFileSync(totalFilePath, totalContent, 'utf-8');
console.log(`결과 저장 : ${totalFilePath}`);