import sys
import json
import requests
import os

REDMINE_API_KEY = "d75db8716d916dce02bf117ef9c8cfc98f91e5e8"
REDMINE_URL = "http://localhost:13001"
ZIP_FILE_PATH = "./lighthouse-reports.zip"
PROJECT_NAME = "session-confirm"
    
try:
    issue_subject = "Lighthouse 테스트 결과"
    with open("./total_value.txt", "r", encoding="utf-8") as file:
        total_value = file.read().strip()
        issue_description = "http://localhost:19003/app/projects/"+PROJECT_NAME+"/dashboard\n"+total_value

    issue_data = {
        "issue": {
            "project_id": 1,
            "tracker_id": 5,
            "subject": issue_subject,
            "description": issue_description
        }
    }

    headers = {
        "Content-Type": "application/json",
        "X-Redmine-API-Key": REDMINE_API_KEY
    }

    response = requests.post(f"{REDMINE_URL}/issues.json", headers=headers, json=issue_data)

    if response.status_code != 201:
        print("Error: Create redmine issue failed")
        print(response.text)
        sys.exit(1)

    issue_id = response.json()["issue"]["id"]
    print(f"Create redmine issue success: {issue_id}")

    # 파일 업로드
    if not os.path.exists(ZIP_FILE_PATH):
        print(f"Error: {ZIP_FILE_PATH} does not exist.")
        sys.exit(1)

    with open(ZIP_FILE_PATH, "rb") as file:
        upload_response = requests.post(f"{REDMINE_URL}/uploads.json", headers={"X-Redmine-API-Key": REDMINE_API_KEY, "Content-Type": "application/octet-stream"}, files={"file": file})

    if upload_response.status_code != 201:
        print("Error: File upload failed")
        print(upload_response.text)
        sys.exit(1)

    upload_token = upload_response.json()["upload"]["token"]
    print(f"File upload success: {upload_token}")

    # 이슈에 첨부파일 추가
    attachment_data = {
        "issue": {
            "uploads": [{
                "token": upload_token,
                "filename": ZIP_FILE_PATH,
                "content_type": "application/zip"
            }]
        }
    }

    attach_headers = {
        "Content-Type": "application/json",
        "X-Redmine-API-Key": REDMINE_API_KEY
    }
    
    attach_response = requests.put(f"{REDMINE_URL}/issues/{issue_id}.json", headers=attach_headers, json=attachment_data)

    if attach_response.status_code not in [200, 204]:
        print("Error: file attach issue failed")
        print(attach_response.text)
        sys.exit(1)

    print("Success upload result and file")

except Exception as e:
    print(f"Exception Error: {e}")
    sys.exit(1)

