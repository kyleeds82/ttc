import asyncio
import json
import os
import requests
from pathlib import Path
from base64 import b64decode
from crawl4ai import AsyncWebCrawler, CacheMode
from playwright.async_api import async_playwright
from urllib.parse import urlparse, urljoin
from bs4 import BeautifulSoup


SMS_CODE_PATH = "./sms_code.txt"
USER_DATA_DIR = "./crawl4ai_url/user-data"
STORAGE_STATE_PATH_A = "./crawl4ai_url/user-data/storage_state_a.json"
STORAGE_STATE_PATH_B = "./crawl4ai_url/user-data/storage_state_b.json"

PLAYWRIGHT_CHROMIUM_PATH = "C:\\Users\\KTDS\\AppData\\Local\\ms-playwright\\chromium-1148\\chrome-win\\chrome.exe"

#SMS_CODE_PATH_A = "crawl4ai_url/sms_code_crawl4ai.txt"
#TWO_FA_CODE_A= "twoFA_code.txt"
#
#USER_DATA_DIR = "crawl4ai_url/user-data"
#STORAGE_STATE_PATH_A = "crawl4ai_url/user-data/storage_state_a.json"
#STORAGE_STATE_PATH_B = "crawl4ai_url/user-data/storage_state_b.json"

#SAVE_DIR = "crawl4ai_url/save_resource"


async def close_dialog(dialog):
            print(f"팝업 메시지: {dialog.message}")
            await dialog.accept()
            print("팝업 닫힘")

async def check_sms_code(txt_path, interval=5):
    while not Path(txt_path).exists():
        print("SMS 코드 파일 없음")
        await asyncio.sleep(interval)
    print("SMS 코드 파일 확인")

def get_domain_name(url):
    parseUrl = urlparse(url)
    hostname = parseUrl.hostname
    return hostname.replace(".", "_")

def get_domain_url(enter_url):
    parsed_url = urlparse(enter_url)
    return parsed_url.netloc

def filter_urls(enter_urls, filter_domain):
    filtered = []
    for enter_url in enter_urls:
        parsed_url = urlparse(enter_url)

        # url이 domain과 불일치 제거
        if filter_domain not in parsed_url.netloc:
            continue

        # http, https가 아니거나 javascript링크가 포함되면 제거
        if parsed_url.scheme not in ["http", "https"] or "javascript" in enter_url:
            continue

        # #문자가 있으면 뒷 부분 버리고 앞 부분 도메인:포트만 저장
        clean_url = enter_url.split("#")[0]

        # 중복되면 저장하지 않음
        if clean_url not in filtered:
            filtered.append(clean_url)
    return filtered

def convert_https(file_path):
    with open(file_path, "r", encoding="utf-8") as file:
        lines = file.readlines() 
    change_lines=[line.replace("http://", "https://") for line in lines if "logout.do" not in line]
    with open(file_path, "w", encoding="utf-8") as file:
        file.writelines(change_lines)
    print("https 변경 후 저장")

#async def save_login_state(url_a, url_b):
async def save_login_state(url_a):   
    async with async_playwright() as p:
        browser = await p.chromium.launch_persistent_context(
            user_data_dir=USER_DATA_DIR,  
            headless=False 
        ) 
        page = await browser.new_page()
        await page.goto(url_a)
        await asyncio.sleep(2)
        await page.screenshot(path="result_sshot/move_url.png", full_page=False)
        
        selector = "#legacy_layPop_wrap0 > div.layPop_title > h2 > span"
        if await page.locator(selector).count() > 0:
            await page.locator(selector).click()
            print("Alert Message Close")
        else:
            print("Nothing Alert Message")

        await page.fill('#login_id_main', "clsncp002")
        await page.fill('#password_main', "clscls2021!")
        await page.screenshot(path="result_sshot/enter_idPw_a.png", full_page=False)
        await asyncio.sleep(5)


        await page.click('#main_visual_skip > div > ul > li:nth-child(2) > div > div > div.login_box > div.btn-box > button')
        await asyncio.sleep(5)
        await page.screenshot(path="result_sshot/login_success_a.png", full_page=False)

        print("로그인 완료")
        currentUrl_a = page.url
        getDomainName_a=get_domain_name(currentUrl_a)
        
        cookies_a = await browser.cookies()
        cookie_path_a = USER_DATA_DIR+f"/cookies_{getDomainName_a}.json"
        with open(cookie_path_a, "w", encoding="utf-8") as f:
            json.dump(cookies_a, f, indent=4)
        await browser.storage_state(path=STORAGE_STATE_PATH_A)

        print("1번째 도메인 로그인 처리 완료")
        await asyncio.sleep(2)
        
        await page.close()
        print("currentUrl_a : ", currentUrl_a)
        print("getDomainName_a :", getDomainName_a)
        return currentUrl_a, getDomainName_a
        #return currentUrl_a, getDomainName_a, currentUrl_b, getDomainName_b

async def crawl4aiGetUrl(enter_crawl_url, storage_state_path, url_label):
    async with AsyncWebCrawler(
        headless=False,
        verbose=False,
        enable_click=True,
        max_depth=1,
        max_pages=100,
        delay=2,
        viewport_width=1280,
        viewport_height=720,
        storage_state=storage_state_path,
        user_data_dir=USER_DATA_DIR,
        #executable_path=PLAYWRIGHT_CHROMIUM_PATH,
        args=["--no-sandbox", "--disable-setuid-sandbox"]
    ) as crawler, async_playwright() as p:
        try:
            result = await crawler.arun(
                url=enter_crawl_url,
                screenshot=False,
                wait_for="document.readyState === 'complete'",
                cache_mode=CacheMode.BYPASS,
            )
            print(f"{url_label} Crawl Success")
        except Exception as e:
            print(f"{url_label} Crawl Failed: {e}")
            return

        # 스크린샷 결과 저장
        #with open(f"C:\\Users\\KTDS\\Downloads\\urlcompare\\crawl4ai_url\\login_result_{url_label}.png", "wb") as f:
        #    f.write(b64decode(result.screenshot))

        # 원본 HTML 저장
        with open(f"./crawl4ai_url/original_page_{url_label}.html", "w", encoding="utf-8") as f:
            f.write(result.html)
        print("Crawling result save as .html FILE")

        # HTML 내용 확인
        soup = BeautifulSoup(result.html, "html.parser")
        url_lists = []

        print(f"크롤링 시작 URL: {enter_crawl_url}")
        # 모든 <a> 태그의 href 추출
        for a_tag in soup.find_all("a", href=True):
            url = urljoin(result.url, a_tag["href"])
            url_lists.append(url)

        all_urls_path = f"./crawl4ai_url/all_urls_{url_label}.txt"
        with open(all_urls_path, "w", encoding="utf-8") as f:
            f.write("\n".join(url_lists))

        # 중복 저장 안함
        if not url_lists:
            url_lists.append(enter_crawl_url)


        filter_domain = get_domain_url(enter_crawl_url)
        filtered_urls = filter_urls(url_lists, filter_domain)

        with open(f"./crawl4ai_url/filtered_urls_{url_label}.txt", "w", encoding="utf-8") as f:
            f.write("\n".join(filtered_urls))
        print("Filtering result save as .txt FILE")
        return filtered_urls

def convert_https(file_path):
    with open(file_path, "r", encoding="utf-8") as file:
        lines = file.readlines() 
    change_lines=[line.replace("http://", "https://") for line in lines if "logout.do" not in line]
    with open(file_path, "w", encoding="utf-8") as file:
        file.writelines(change_lines)
    print("https 변경 후 저장")
    
def compare_urls(list_a, compare_num):
    COMPARE_FILE_PATH = "./crawl4ai_url/compare_list.txt"
    compare_number = compare_num

    select_a = list_a[:compare_number] if list_a else []
    
    with open(COMPARE_FILE_PATH, "w", encoding="utf-8") as f:
        f.write("\n".join(select_a))

    print("비교 리스트 저장 성공")
    convert_https(COMPARE_FILE_PATH)

#def compare_urls(list_a, list_b, compare_num):
#    COMPARE_FILE_PATH = "./crawl4ai_url/compare_list.txt"
#    compare_number = compare_num
#
#    select_a = list_a[:compare_number] if list_a else []
#    select_b = list_b[:compare_number] if list_b else []
#
#    with open(COMPARE_FILE_PATH, "w", encoding="utf-8") as f:
#        f.write("\n".join(select_a + select_b))
#
#    print("비교 리스트 저장 성공")
#    convert_https(COMPARE_FILE_PATH)

async def main():
    #url_a, url_name_a, url_b, url_name_b = asyncio.run(save_login_state("https://auth.ncloud.com/login", "https://shop.kt.com/mobile/products.do?&=&category=mobile"))

    # 첫 번째 도메인
    CRAWL_URL_A = "https://cls.edunet.net/"
    domain_a = get_domain_url(CRAWL_URL_A)
    url_a, url_name_a = await save_login_state(CRAWL_URL_A)
    top_list_a = await crawl4aiGetUrl(url_a, STORAGE_STATE_PATH_A, url_name_a)
    compare_urls(top_list_a, 3)

    # 두 번째 도메인
    #url_b, url_name_b = asyncio.run(save_login_state("https://auth.ncloud.com/login"))
    #filtered_urls_b = asyncio.run(crawl4aiGetUrl(url_b, STORAGE_STATE_PATH_B, url_name_b))
    #all_filtered_urls.extend(filtered_urls_b)


    # 2번째 크롤링 시작
    with open("./crawl4ai_url/compare_list.txt", "r", encoding="utf-8") as f:
        second_crawl4ai_url = [line.strip() for line in f.readlines() if line.strip()]

    second_crawl4ai_list = []
    label_num = 1

    for crawl4ai_url in second_crawl4ai_url:
        crwal_list = asyncio.create_task(crawl4aiGetUrl(crawl4ai_url, STORAGE_STATE_PATH_A, f"{url_name_a}_second{label_num}"))
        second_crawl4ai_list.append(crwal_list)
        label_num += 1

    await asyncio.gather(*second_crawl4ai_list)
    await merge_filtered_urls(url_name_a, domain_a)


async def merge_filtered_urls(label_domain, domain_name):
    folder_path = "./crawl4ai_url/"
    filtered_urls = []

    # 해당 폴더의 모든 파일 중 특정 패턴에 맞는 파일 선택
    file_list = [
        os.path.join(folder_path, file) for file in os.listdir(folder_path)
        if file.startswith(f"filtered_urls_{label_domain}_second") and file.endswith(".txt")
    ]
    print(f"최종 선택된 파일 목록: {file_list}")

    # 각 파일에서 URL 읽기
    for file_path in file_list:
        if os.path.exists(file_path):
            with open(file_path, "r", encoding="utf-8") as f:
                urls = [line.strip() for line in f.readlines() if line.strip()]
                print(f"현재 파일: {file_path}")
                print(f"읽어온 URL 개수: {len(urls)}")
                filtered_urls.extend(urls)

    print(filtered_urls)
    filtered_urls = filter_urls(filtered_urls, domain_name)

    merged_second_url = f"./crawl4ai_url/second_crawl_{label_domain}_url.txt"
    with open(merged_second_url, "w", encoding="utf-8") as f:
        f.write("\n".join(filtered_urls))


if __name__ == "__main__":
    # 전체 실행
    asyncio.run(main())